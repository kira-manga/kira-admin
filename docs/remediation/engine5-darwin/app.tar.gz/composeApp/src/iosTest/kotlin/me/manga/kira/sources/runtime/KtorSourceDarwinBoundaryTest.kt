package me.manga.kira.sources.runtime

import io.ktor.client.engine.darwin.Darwin
import kotlinx.coroutines.test.runTest
import kotlin.test.Test

/** Requires the real simulator runtime; native MockEngine execution is not a substitute. */
class KtorSourceDarwinBoundaryTest {
    @Test
    fun darwin_single_hop_bridge_cancellation_and_managed_closure() = runTest {
        verifyRealSourceHttpBoundary(Darwin)
    }
}
