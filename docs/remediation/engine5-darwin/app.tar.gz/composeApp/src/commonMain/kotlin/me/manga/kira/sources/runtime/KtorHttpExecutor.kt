package me.manga.kira.sources.runtime

import io.ktor.client.HttpClient
import io.ktor.client.plugins.HttpRedirect
import io.ktor.client.plugins.pluginOrNull
import io.ktor.client.request.HttpRequestBuilder
import io.ktor.client.request.forms.submitForm
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.Parameters
import io.ktor.http.contentType
import me.manga.kira.sources.contracts.HttpExecutor
import me.manga.kira.sources.contracts.SourceHttpMethod
import me.manga.kira.sources.contracts.SourceRequest
import me.manga.kira.sources.contracts.SourceResponse

/**
 * Single-hop Ktor implementation of [HttpExecutor]. Owns one no-follow child of the app's shared
 * [HttpClient], retaining its engine and other configured policies without changing other callers.
 * The source engine must inspect each redirect and select headers before the next destination.
 *
 * Living here (the composition root) rather than in `:sources:engine` is deliberate: it keeps the
 * engine free of any HTTP-library dependency, so the engine stays unit-testable with a fake executor.
 * It is the live transport for every config-backed generic source (engine="generic" stanza) — exercised on each
 * generic home/featured/search/details/pages call.
 */
class KtorHttpExecutor(
    client: HttpClient,
) : HttpExecutor {
    private val sourceClient =
        client.config {
            followRedirects = false
            expectSuccess = false
        }.also { child ->
            // The flag omits Ktor's implicit plugin, but cannot remove an explicitly installed one.
            if (child.pluginOrNull(HttpRedirect) != null) {
                child.close()
                error("Source transport must not install HttpRedirect")
            }
        }

    override suspend fun execute(request: SourceRequest): SourceResponse {
        val response: HttpResponse = when (request.method) {
            SourceHttpMethod.GET -> sourceClient.get(request.url) { applyHeaders(request.headers) }
            SourceHttpMethod.POST_FORM -> sourceClient.submitForm(
                url = request.url,
                formParameters = Parameters.build { request.formBody?.forEach { (k, v) -> append(k, v) } },
            ) { applyHeaders(request.headers) }
            SourceHttpMethod.POST_JSON -> sourceClient.post(request.url) {
                applyHeaders(request.headers)
                contentType(ContentType.Application.Json)
                setBody(request.jsonBody ?: "{}")
            }
        }
        return SourceResponse(
            status = response.status.value,
            body = response.bodyAsText(),
            headers = response.sourceHeaders(),
        )
    }

    /** Starts closing only the owned child; the shared client's owner must close that client too. */
    fun close() {
        sourceClient.close()
    }

    private fun HttpResponse.sourceHeaders(): Map<String, String> = buildMap {
        headers.entries().forEach { (name, values) ->
            if (!name.equals(HttpHeaders.Location, ignoreCase = true)) {
                // Kept for compatibility, not a lossless Set-Cookie representation.
                put(name, values.joinToString(", "))
            }
        }
        // Multiple fields are ambiguous. A comma inside ONE field is legal URI data, not a split.
        headers.getAll(HttpHeaders.Location)?.singleOrNull()?.let { put(HttpHeaders.Location, it) }
    }

    private fun HttpRequestBuilder.applyHeaders(headers: Map<String, String>) {
        headers.forEach { (key, value) -> header(key, value) }
    }
}
