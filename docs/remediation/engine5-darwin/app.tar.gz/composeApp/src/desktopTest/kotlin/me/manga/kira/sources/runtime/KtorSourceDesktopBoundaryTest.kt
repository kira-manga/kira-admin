package me.manga.kira.sources.runtime

import io.ktor.client.HttpClient
import io.ktor.client.engine.cio.CIO
import io.ktor.client.engine.okhttp.OkHttp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.job
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import me.manga.kira.data.remote.di.remoteModule
import me.manga.kira.di.sourcesGenericModule
import me.manga.kira.sources.contracts.HttpExecutor
import org.koin.core.KoinApplication
import org.koin.dsl.koinApplication
import java.nio.file.Files
import java.nio.file.Path
import kotlin.test.Test
import kotlin.test.assertSame
import kotlin.test.assertTrue
import kotlin.time.Duration.Companion.seconds

class KtorSourceDesktopBoundaryTest {
    @Test
    fun cio_single_hop_bridge_cancellation_and_managed_closure() = runTest {
        verifyRealSourceHttpBoundary(CIO)
    }

    @Test
    fun okhttp_single_hop_bridge_cancellation_and_managed_closure() = runTest {
        verifyRealSourceHttpBoundary(OkHttp)
    }

    @Test
    fun production_remote_and_source_modules_dispose_both_managed_clients() = runTest {
        withRemoteGraph { app, root, executor ->
            assertSame(executor, app.koin.get<HttpExecutor>())
            app.close()
            withContext(Dispatchers.Default) {
                withTimeout(5.seconds) {
                    root.coroutineContext.job.join()
                    root.engine.coroutineContext.job.join()
                }
            }
            assertTrue(root.coroutineContext.job.isCompleted)
            assertTrue(root.engine.coroutineContext.job.isCompleted)
        }
    }

    private suspend fun withRemoteGraph(block: suspend (KoinApplication, HttpClient, KtorHttpExecutor) -> Unit) {
        val home = Files.createTempDirectory("source-http-di-")
        val app = koinApplication {
            allowOverride(false)
            modules(remoteModule(), sourcesGenericModule)
        }
        var root: HttpClient? = null
        var executor: KtorHttpExecutor? = null
        try {
            val ownedRoot = withTemporaryHome(home) { app.koin.get<HttpClient>() }
            root = ownedRoot
            val ownedExecutor = app.koin.get<KtorHttpExecutor>()
            executor = ownedExecutor
            block(app, ownedRoot, ownedExecutor)
        } finally {
            try {
                app.close()
                root?.let { closeSourceHttpClients(it, executor) }
            } finally {
                assertTrue(home.toFile().deleteRecursively(), "Remove the test-owned HTTP cache")
            }
        }
    }

    private inline fun <T> withTemporaryHome(home: Path, block: () -> T): T {
        val original = System.getProperty("user.home")
        try {
            // The real desktop factory creates a file cache. Keep that out of the developer's home.
            System.setProperty("user.home", home.toString())
            return block()
        } finally {
            if (original == null) System.clearProperty("user.home") else System.setProperty("user.home", original)
        }
    }
}
