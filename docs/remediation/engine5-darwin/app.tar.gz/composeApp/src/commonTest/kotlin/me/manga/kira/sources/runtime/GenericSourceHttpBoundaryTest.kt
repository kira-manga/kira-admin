package me.manga.kira.sources.runtime

import io.ktor.client.engine.mock.MockRequestHandleScope
import io.ktor.client.engine.mock.respond
import io.ktor.http.Headers
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpMethod
import io.ktor.http.HttpStatusCode
import io.ktor.http.headersOf
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import me.manga.kira.core.error.AppError
import me.manga.kira.core.result.AppResult
import me.manga.kira.domain.model.Chapter
import me.manga.kira.domain.model.Manga
import me.manga.kira.domain.model.filters.FilterSelections
import me.manga.kira.domain.model.home.HomeFeedItem
import me.manga.kira.domain.model.reader.Page
import me.manga.kira.sources.contracts.model.FilterDefinition
import me.manga.kira.sources.contracts.model.FilterRequestSpec
import me.manga.kira.sources.engine.GenericSourceClient
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertIs
import kotlin.test.assertNull

/** Run against the exact reviewed neutral engine tree, not the unchanged published 0.1.0 pin. */
class GenericSourceHttpBoundaryTest {
    @Test
    fun real_bridge_reselects_whole_header_snapshot_for_trusted_foreign_trusted_hops() = runTest {
        withSourceHttp({ request ->
            when (request.url.encodedPath) {
                "/start" -> redirectTo("$FOREIGN/foreign")
                "/foreign" -> redirectTo("$SOURCE_HTTP_ORIGIN/done", HttpStatusCode.TemporaryRedirect)
                else -> respond(SOURCE_HTTP_HOME)
            }
        }) {
            val store = SourceHttpHeaderStore()
            val client = GenericSourceClient(searchConfig(), executor, store)
            val filters = FilterSelections(mapOf("context" to listOf("filter-sentinel")))
            val result = assertIs<AppResult.Success<List<HomeFeedItem>>>(client.search("synthetic", 1, filters))
            assertEquals(listOf("Synthetic manga"), result.value.map { it.title })
            val sent = engine.requestHistory
            assertEquals(listOf("source.test", "foreign.test", "source.test"), sent.map { it.url.host })
            assertSourceHttpHeaders(sent[0].headers, sourceHttpHeaders)
            assertSourceHttpHeaders(sent[1].headers, emptyMap())
            assertSourceHttpHeaders(sent[2].headers, sourceHttpHeaders)
            assertEquals("filter-sentinel", sent[0].headers["X-Filter"])
            assertNull(sent[1].headers["X-Filter"])
            assertEquals("filter-sentinel", sent[2].headers["X-Filter"])
            assertEquals(1, store.reads)
        }
    }

    @Test
    fun public_redirects_still_resolve_without_a_captured_header_read() = runTest {
        withSourceHttp({ request ->
            if (request.url.encodedPath == "/start") {
                redirectTo("../public,a?b=c,d", HttpStatusCode.SeeOther)
            } else {
                respond(SOURCE_HTTP_HOME)
            }
        }) {
            val store = SourceHttpHeaderStore()
            val config = sourceHttpConfig().copy(headers = emptyMap(), usesCapturedHeaders = false)
            val result = GenericSourceClient(config, executor, store).home(1)
            assertIs<AppResult.Success<List<HomeFeedItem>>>(result)
            assertEquals(listOf("/start", "/public,a"), engine.requestHistory.map { it.url.encodedPath })
            engine.requestHistory.forEach { assertSourceHttpHeaders(it.headers, emptyMap()) }
            assertEquals(0, store.reads)
        }
    }

    @Test
    fun domain_pages_keep_each_image_header_decision_for_trusted_and_foreign_chapter_requests() = runTest {
        listOf(SOURCE_HTTP_ORIGIN, FOREIGN).forEach { verifyPageHeaders(it) }
    }

    @Test
    fun neither_post_body_type_is_replayed_for_any_redirect_status() = runTest {
        listOf("post-form", "post-json").forEach { method ->
            sourceHttpRedirectStatuses.forEach { status ->
                withSourceHttp({
                    redirectTo("$FOREIGN/replay", HttpStatusCode.fromValue(status))
                }) {
                    val base = sourceHttpConfig()
                    val endpoint = base.endpoints.getValue("home").copy(
                        method = method,
                        formBody = mapOf("static" to "synthetic"),
                        jsonBody = """{"value":"synthetic"}""",
                    )
                    val config = base.copy(endpoints = base.endpoints + ("home" to endpoint))
                    val result = GenericSourceClient(config, executor, SourceHttpHeaderStore()).home(1)
                    assertEquals(AppError.Network.Http(status), assertIs<AppResult.Failure>(result).error)
                    val sent = engine.requestHistory.single()
                    assertEquals(HttpMethod.Post, sent.method)
                    assertEquals("source.test", sent.url.host)
                    assertSourceHttpHeaders(sent.headers, sourceHttpHeaders)
                }
            }
        }
    }

    @Test
    fun missing_or_multiple_location_fields_stay_http_failures_without_a_second_destination() = runTest {
        listOf(false, true).forEach { duplicate ->
            withSourceHttp({
                respond("redirect", HttpStatusCode.Found, Headers.build {
                    if (duplicate) {
                        append("Location", "$FOREIGN/one")
                        append("location", "$FOREIGN/two")
                    }
                })
            }) {
                val result = GenericSourceClient(sourceHttpConfig(), executor, SourceHttpHeaderStore()).home(1)
                assertEquals(AppError.Network.Http(302), assertIs<AppResult.Failure>(result).error)
                assertEquals(1, engine.requestHistory.size)
            }
        }
    }

    @Test
    fun malformed_next_destination_maps_to_serialization_failure_before_another_send() = runTest {
        withSourceHttp({
            redirectTo("https://source.test@foreign.test/path")
        }) {
            val result = GenericSourceClient(sourceHttpConfig(), executor, SourceHttpHeaderStore()).home(1)
            assertIs<AppError.Network.Serialization>(assertIs<AppResult.Failure>(result).error)
            assertEquals(1, engine.requestHistory.size)
        }
    }

    @Test
    fun real_bridge_preserves_transport_cancellation_instead_of_mapping_it_to_app_failure() = runTest {
        var sends = 0
        withSourceHttp({
            sends++
            throw CancellationException("synthetic cancellation")
        }) {
            val client = GenericSourceClient(sourceHttpConfig(), executor, SourceHttpHeaderStore())
            assertFailsWith<CancellationException> { client.home(1) }
            assertEquals(1, sends)
        }
    }

    private suspend fun verifyPageHeaders(chapterOrigin: String) {
        val urls = listOf(
            "$SOURCE_HTTP_ORIGIN/one.jpg", "https://images.test/two.jpg", "https://trusted.test/three.jpg",
            "$FOREIGN/four.jpg", "https://cdn.trusted.test/five.jpg", "https://history.test/six.jpg",
        )
        val body = """{"pages":[${urls.joinToString(",") { """{"image":"$it"}""" }}]}"""
        withSourceHttp({ respond(body) }) {
            val store = SourceHttpHeaderStore()
            val config = sourceHttpConfig().copy(
                imageBase = "https://images.test",
                trustedHosts = listOf("trusted.test"),
                previousHosts = listOf("history.test"),
            )
            val manga = Manga(config.api, "en", "synthetic", "$SOURCE_HTTP_ORIGIN/manga", "", null, emptyList())
            val chapter = Chapter("1", "", "$chapterOrigin/chapter", null, false, false)
            val client = GenericSourceClient(config, executor, store)
            val pages = assertIs<AppResult.Success<List<Page>>>(client.pages(manga, chapter).first()).value
            assertEquals(urls, pages.map { it.url })
            assertEquals(List(3) { sourceHttpHeaders } + List(3) { emptyMap() }, pages.map { it.headers })
            val expected = if (chapterOrigin == SOURCE_HTTP_ORIGIN) sourceHttpHeaders else emptyMap()
            assertSourceHttpHeaders(engine.requestHistory.single().headers, expected)
            assertEquals(1, store.reads)
        }
    }

    private fun searchConfig() = sourceHttpConfig().let { base ->
        base.copy(
            endpoints = base.endpoints + ("search" to base.endpoints.getValue("home")),
            filters = listOf(
                FilterDefinition(
                    id = "context",
                    label = "Synthetic context",
                    type = "text",
                    request = FilterRequestSpec(target = "header", param = "X-Filter"),
                ),
            ),
        )
    }

    private fun MockRequestHandleScope.redirectTo(location: String, status: HttpStatusCode = HttpStatusCode.Found) =
        respond("redirect", status, headersOf(HttpHeaders.Location, location))

    private companion object {
        const val FOREIGN = "https://foreign.test"
    }
}
