package me.manga.kira.sources.runtime

import io.ktor.client.HttpClient
import io.ktor.client.engine.mock.MockEngine
import io.ktor.client.engine.mock.MockRequestHandler
import io.ktor.client.plugins.api.createClientPlugin
import io.ktor.http.Headers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.cancel
import kotlinx.coroutines.job
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import me.manga.kira.sources.contracts.HeaderStore
import me.manga.kira.sources.contracts.model.EndpointSpec
import me.manga.kira.sources.contracts.model.FieldSpec
import me.manga.kira.sources.contracts.model.SourceConfig
import kotlin.test.assertEquals
import kotlin.time.Duration.Companion.seconds

internal const val SOURCE_HTTP_ORIGIN = "https://source.test"
internal const val SOURCE_HTTP_HOME =
    """{"items":[{"title":"Synthetic manga","url":"/manga","cover":"/cover.jpg"}]}"""
internal val sourceHttpStaticHeaders = mapOf("X-Static" to "static-sentinel", "Referer" to "$SOURCE_HTTP_ORIGIN/")
internal val sourceHttpCapturedHeaders =
    mapOf("Cookie" to "cookie-sentinel", "aUtHoRiZaTiOn" to "auth-sentinel", "X-Captured" to "capture-sentinel")
internal val sourceHttpHeaders = sourceHttpStaticHeaders + sourceHttpCapturedHeaders
internal val sourceHttpRedirectStatuses = listOf(301, 302, 303, 307, 308)

/** Observes real plugin installation without exposing the executor's private child in production. */
internal class SourceHttpClientProbe {
    val clients = mutableListOf<HttpClient>()
    val plugin = createClientPlugin("SourceHttpClientProbe") { clients += client }

    fun childOf(root: HttpClient): HttpClient = clients.single { it !== root }
}

internal class SourceHttpTestFixture(
    val root: HttpClient,
    val executor: KtorHttpExecutor,
    val probe: SourceHttpClientProbe,
) {
    val child: HttpClient get() = probe.childOf(root)
    val engine: MockEngine get() = root.engine as MockEngine
}

internal suspend fun withSourceHttp(
    handler: MockRequestHandler,
    block: suspend SourceHttpTestFixture.() -> Unit,
) {
    val probe = SourceHttpClientProbe()
    // Factory form is intentional: unlike HttpClient(existingEngine), it manages the engine.
    val root = HttpClient(MockEngine) {
        followRedirects = true
        expectSuccess = true
        install(probe.plugin)
        engine { addHandler(handler) }
    }
    var executor: KtorHttpExecutor? = null
    try {
        val owned = KtorHttpExecutor(root)
        executor = owned
        SourceHttpTestFixture(root, owned, probe).block()
    } finally {
        closeSourceHttpClients(root, executor)
    }
}

internal suspend fun closeSourceHttpClients(root: HttpClient, executor: KtorHttpExecutor?) {
    withContext(NonCancellable + Dispatchers.Default) {
        try {
            executor?.close()
            root.close()
            withTimeout(5.seconds) {
                root.coroutineContext.job.join()
                root.engine.coroutineContext.job.join()
            }
        } finally {
            // Failure cleanup only: successful ownership assertions must finish before this point.
            if (!root.engine.coroutineContext.job.isCompleted) root.engine.coroutineContext.cancel()
        }
    }
}

internal class SourceHttpHeaderStore : HeaderStore {
    var reads = 0
        private set

    override suspend fun headersFor(api: String): Map<String, String> {
        reads++
        return sourceHttpCapturedHeaders
    }

    override suspend fun save(api: String, headers: Map<String, String>) = Unit
}

internal fun sourceHttpConfig(baseUrl: String = SOURCE_HTTP_ORIGIN): SourceConfig =
    SourceConfig(
        api = "source-http-fixture",
        language = "en",
        engine = "generic",
        baseUrl = baseUrl,
        headers = sourceHttpStaticHeaders,
        endpoints = mapOf(
            "home" to EndpointSpec(url = "{baseUrl}/start", format = "json", root = "items"),
            "pages" to EndpointSpec(url = "{chapterUrl}", format = "json", root = "pages"),
        ),
        fields = mapOf(
            "item.title" to FieldSpec(path = "title"),
            "item.url" to FieldSpec(path = "url"),
            "item.cover" to FieldSpec(path = "cover"),
            "page.image" to FieldSpec(path = "image"),
        ),
    )

internal fun assertSourceHttpHeaders(actual: Headers, expected: Map<String, String>) {
    sourceHttpHeaders.keys.forEach { name -> assertEquals(expected[name], actual[name], name) }
}
