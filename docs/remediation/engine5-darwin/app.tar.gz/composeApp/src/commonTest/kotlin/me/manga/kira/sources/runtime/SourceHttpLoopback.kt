package me.manga.kira.sources.runtime

import io.ktor.http.Headers
import io.ktor.http.HeadersBuilder
import io.ktor.network.selector.SelectorManager
import io.ktor.network.sockets.ServerSocket
import io.ktor.network.sockets.Socket
import io.ktor.network.sockets.aSocket
import io.ktor.network.sockets.openReadChannel
import io.ktor.network.sockets.port
import io.ktor.utils.io.ByteChannel
import io.ktor.utils.io.readLineStrict
import io.ktor.utils.io.writeStringUtf8
import kotlinx.coroutines.CompletableJob
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.job
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlin.time.Duration.Companion.seconds

internal data class SourceHttpWireRequest(val origin: String, val path: String, val headers: Headers)

/** Two ephemeral loopback origins; only the small GET fixture protocol is supported. */
internal class SourceHttpLoopback(private val servers: List<ServerSocket>, scope: CoroutineScope) {
    val origin = servers[0].origin()
    val foreignOrigin = servers[1].origin()
    val requests = Channel<SourceHttpWireRequest>(Channel.UNLIMITED)
    private val jobs = servers.map { server -> scope.launch(Dispatchers.Default) { serve(server) } }

    suspend fun stop() {
        jobs.forEach { it.cancel() }
        servers.forEach { it.close() }
        try {
            jobs.joinAll()
            servers.forEach { it.socketContext.join() }
        } finally {
            requests.close()
        }
    }

    private suspend fun serve(server: ServerSocket) {
        while (currentCoroutineContext().isActive) {
            val socket = server.accept()
            try {
                val request = socket.readRequest(server.origin())
                requests.send(request)
                when (request.path) {
                    "/single", "/start" -> socket.respond(status = 302, location = "$foreignOrigin/foreign")
                    "/foreign" -> socket.respond(status = 307, location = "$origin/done")
                    "/hold" -> awaitCancellation() // Last case; stop() owns this suspended connection.
                    else -> socket.respond(body = SOURCE_HTTP_HOME)
                }
            } finally {
                socket.close()
                withContext(NonCancellable) { socket.socketContext.join() }
            }
        }
    }

    private suspend fun Socket.readRequest(origin: String): SourceHttpWireRequest {
        val input = openReadChannel()
        val requestLine = checkNotNull(input.readLineStrict(limit = MAX_LINE))
        val path = requestLine.split(' ', limit = 3)[1]
        val headers = HeadersBuilder()
        repeat(MAX_HEADERS) {
            val line = checkNotNull(input.readLineStrict(limit = MAX_LINE))
            if (line.isEmpty()) return SourceHttpWireRequest(origin, path, headers.build())
            val separator = line.indexOf(':')
            check(separator > 0)
            headers.append(line.substring(0, separator), line.substring(separator + 1).trim())
        }
        error("Too many fixture request headers")
    }

    private suspend fun Socket.respond(status: Int = 200, location: String? = null, body: String = "") {
        val output = ByteChannel(autoFlush = true)
        val writer = attachForWriting(output)
        val head = buildString {
            append("HTTP/1.1 $status Fixture\r\n")
            if (location != null) append("Location: $location\r\n")
            append("Content-Type: application/json\r\n")
            append("Content-Length: ${body.encodeToByteArray().size}\r\n")
            append("Cache-Control: no-store\r\nConnection: close\r\n\r\n")
        }
        output.writeStringUtf8(head + body)
        output.flushAndClose()
        writer.job.join()
    }

    private companion object {
        const val MAX_LINE = 8_192L
        const val MAX_HEADERS = 64

        fun ServerSocket.origin(): String = "http://127.0.0.1:$port"
    }
}

internal suspend fun withSourceHttpLoopback(block: suspend SourceHttpLoopback.() -> Unit) = coroutineScope {
    val selectorJob = Job(coroutineContext.job)
    val selector = SelectorManager(Dispatchers.Default + selectorJob)
    val servers = mutableListOf<ServerSocket>()
    var loopback: SourceHttpLoopback? = null
    try {
        repeat(2) { servers += aSocket(selector).tcp().bind("127.0.0.1", 0) }
        val fixture = SourceHttpLoopback(servers, this)
        loopback = fixture
        fixture.block()
    } finally {
        closeLoopback(loopback, servers, selector, selectorJob)
    }
}

private suspend fun closeLoopback(
    loopback: SourceHttpLoopback?,
    servers: List<ServerSocket>,
    selector: SelectorManager,
    selectorJob: CompletableJob,
) = withContext(NonCancellable + Dispatchers.Default) {
    try {
        withTimeout(5.seconds) {
            if (loopback != null) {
                loopback.stop()
            } else {
                servers.forEach { it.close() }
                servers.forEach { it.socketContext.join() }
            }
        }
    } finally {
        selector.close()
        selectorJob.complete()
        withTimeout(5.seconds) { selectorJob.join() }
    }
}
