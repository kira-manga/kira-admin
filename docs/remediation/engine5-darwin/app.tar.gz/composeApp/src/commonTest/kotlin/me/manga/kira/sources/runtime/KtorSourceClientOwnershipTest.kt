package me.manga.kira.sources.runtime

import io.ktor.client.HttpClient
import io.ktor.client.engine.mock.MockEngine
import io.ktor.client.engine.mock.respond
import io.ktor.client.plugins.HttpRedirect
import io.ktor.client.request.get
import io.ktor.client.statement.bodyAsText
import kotlinx.coroutines.job
import kotlinx.coroutines.test.runTest
import me.manga.kira.core.result.AppResult
import me.manga.kira.di.sourcesGenericModule
import me.manga.kira.sources.contracts.HttpExecutor
import me.manga.kira.sources.contracts.SourceRequest
import me.manga.kira.sources.engine.GenericSourceClient
import org.koin.dsl.koinApplication
import org.koin.dsl.module
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertIs
import kotlin.test.assertSame
import kotlin.test.assertTrue

class KtorSourceClientOwnershipTest {
    @Test
    fun koin_alias_and_multiple_sources_share_one_owned_child() = runTest {
        val probe = SourceHttpClientProbe()
        val root = ownershipRoot(probe)
        val app = koinApplication {
            allowOverride(false)
            modules(sourcesGenericModule, module { single<HttpClient> { root } })
        }
        try {
            val concrete = app.koin.get<KtorHttpExecutor>()
            val alias = app.koin.get<HttpExecutor>()
            assertSame(concrete, alias)
            repeat(2) {
                assertSame(alias, app.koin.get<HttpExecutor>())
                val client = GenericSourceClient(sourceHttpConfig(), alias, SourceHttpHeaderStore())
                assertIs<AppResult.Success<*>>(client.home(1))
            }
            assertEquals(2, probe.clients.size)
            app.close()
            probe.childOf(root).coroutineContext.job.join()
            assertTrue(root.coroutineContext.job.isActive)
            assertEquals(SOURCE_HTTP_HOME, root.get("$SOURCE_HTTP_ORIGIN/still-open").bodyAsText())
        } finally {
            app.close()
            closeSourceHttpClients(root, null)
        }
    }

    @Test
    fun closing_the_source_child_does_not_close_the_managed_root_or_engine() = runTest {
        withSourceHttp({ respond("ok") }) {
            assertSame(root.engine, child.engine)
            executor.close()
            executor.close()
            child.coroutineContext.job.join()
            assertTrue(root.coroutineContext.job.isActive)
            assertTrue(root.engine.coroutineContext.job.isActive)
            assertEquals("ok", root.get("$SOURCE_HTTP_ORIGIN/still-open").bodyAsText())
            root.close()
            root.coroutineContext.job.join()
            root.engine.coroutineContext.job.join()
            assertTrue(root.engine.coroutineContext.job.isCompleted)
        }
    }

    @Test
    fun closing_the_managed_root_does_not_close_the_source_child_until_both_owners_close() = runTest {
        withSourceHttp({ respond("ok") }) {
            root.close()
            root.coroutineContext.job.join()
            assertTrue(child.coroutineContext.job.isActive)
            assertTrue(root.engine.coroutineContext.job.isActive)
            assertEquals("ok", executor.execute(SourceRequest("$SOURCE_HTTP_ORIGIN/still-open")).body)
            executor.close()
            child.coroutineContext.job.join()
            root.engine.coroutineContext.job.join()
            assertTrue(root.engine.coroutineContext.job.isCompleted)
        }
    }

    @Test
    fun explicitly_inherited_redirect_plugin_is_rejected_and_failed_child_is_disposed() = runTest {
        val probe = SourceHttpClientProbe()
        val root = ownershipRoot(probe, explicitRedirect = true)
        var unexpectedExecutor: KtorHttpExecutor? = null
        try {
            assertFailsWith<IllegalStateException> { unexpectedExecutor = KtorHttpExecutor(root) }
            val rejectedChild = probe.childOf(root)
            rejectedChild.coroutineContext.job.join()
            assertTrue(rejectedChild.coroutineContext.job.isCompleted)
            assertTrue(root.coroutineContext.job.isActive)
            assertTrue(root.engine.coroutineContext.job.isActive)
            assertEquals(SOURCE_HTTP_HOME, root.get("$SOURCE_HTTP_ORIGIN/still-open").bodyAsText())
        } finally {
            closeSourceHttpClients(root, unexpectedExecutor)
        }
    }

    private fun ownershipRoot(probe: SourceHttpClientProbe, explicitRedirect: Boolean = false): HttpClient =
        HttpClient(MockEngine) {
            followRedirects = true
            expectSuccess = true
            install(probe.plugin)
            if (explicitRedirect) install(HttpRedirect)
            engine { addHandler { respond(SOURCE_HTTP_HOME) } }
        }
}
