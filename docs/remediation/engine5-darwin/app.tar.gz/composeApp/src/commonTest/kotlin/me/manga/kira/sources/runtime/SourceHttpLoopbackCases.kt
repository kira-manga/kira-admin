package me.manga.kira.sources.runtime

import io.ktor.client.HttpClient
import io.ktor.client.engine.HttpClientEngineConfig
import io.ktor.client.engine.HttpClientEngineFactory
import io.ktor.client.plugins.HttpRedirect
import io.ktor.client.plugins.pluginOrNull
import io.ktor.http.HttpHeaders
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.job
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import me.manga.kira.core.result.AppResult
import me.manga.kira.domain.model.home.HomeFeedItem
import me.manga.kira.sources.contracts.SourceRequest
import me.manga.kira.sources.engine.GenericSourceClient
import kotlin.test.assertEquals
import kotlin.test.assertIs
import kotlin.test.assertNull
import kotlin.test.assertTrue
import kotlin.time.Duration.Companion.seconds

/** Real engine coverage shared by JVM CIO/OkHttp and the Darwin simulator test. */
internal suspend fun <T : HttpClientEngineConfig> verifyRealSourceHttpBoundary(factory: HttpClientEngineFactory<T>) {
    withContext(Dispatchers.Default) {
        withTimeout(20.seconds) {
            withSourceHttpLoopback {
                withRealSourceClients(factory) { root, executor, child ->
                    assertNull(child.pluginOrNull(HttpRedirect))
                    verifySingleHop(executor)
                    verifyEngineRedirects(executor)
                    verifyRootClose(root, executor, child)
                    verifyCancellation(executor)
                }
            }
        }
    }
}

private suspend fun <T : HttpClientEngineConfig> withRealSourceClients(
    factory: HttpClientEngineFactory<T>,
    block: suspend (HttpClient, KtorHttpExecutor, HttpClient) -> Unit,
) {
    val probe = SourceHttpClientProbe()
    val root = HttpClient(factory) {
        followRedirects = true
        expectSuccess = true
        install(probe.plugin)
    }
    var executor: KtorHttpExecutor? = null
    try {
        val owned = KtorHttpExecutor(root)
        executor = owned
        block(root, owned, probe.childOf(root))
    } finally {
        closeSourceHttpClients(root, executor)
    }
    assertTrue(probe.clients.all { it.coroutineContext.job.isCompleted })
    assertTrue(root.engine.coroutineContext.job.isCompleted)
}

private suspend fun SourceHttpLoopback.verifySingleHop(executor: KtorHttpExecutor) {
    val response = executor.execute(SourceRequest("$origin/single", headers = sourceHttpHeaders))
    assertEquals(302, response.status)
    assertEquals("$foreignOrigin/foreign", response.headers[HttpHeaders.Location])
    val request = requests.receive()
    assertEquals(origin, request.origin)
    assertEquals("/single", request.path)
    assertSourceHttpHeaders(request.headers, sourceHttpHeaders)
    assertTrue(requests.tryReceive().isFailure)
}

private suspend fun SourceHttpLoopback.verifyEngineRedirects(executor: KtorHttpExecutor) {
    val store = SourceHttpHeaderStore()
    val client = GenericSourceClient(sourceHttpConfig(origin), executor, store)
    val result = assertIs<AppResult.Success<List<HomeFeedItem>>>(client.home(1))
    assertEquals(listOf("Synthetic manga"), result.value.map { it.title })
    val sent = List(3) { requests.receive() }
    assertEquals(listOf(origin, foreignOrigin, origin), sent.map { it.origin })
    assertEquals(listOf("/start", "/foreign", "/done"), sent.map { it.path })
    assertSourceHttpHeaders(sent[0].headers, sourceHttpHeaders)
    assertSourceHttpHeaders(sent[1].headers, emptyMap())
    assertSourceHttpHeaders(sent[2].headers, sourceHttpHeaders)
    assertEquals(1, store.reads)
    assertTrue(requests.tryReceive().isFailure)
}

private suspend fun SourceHttpLoopback.verifyRootClose(
    root: HttpClient,
    executor: KtorHttpExecutor,
    child: HttpClient,
) {
    root.close()
    root.coroutineContext.job.join()
    assertTrue(child.coroutineContext.job.isActive)
    assertTrue(root.engine.coroutineContext.job.isActive)
    assertEquals(200, executor.execute(SourceRequest("$origin/after-parent-close")).status)
    assertEquals("/after-parent-close", requests.receive().path)
}

private suspend fun SourceHttpLoopback.verifyCancellation(executor: KtorHttpExecutor) = coroutineScope {
    val pending = async { executor.execute(SourceRequest("$origin/hold", headers = sourceHttpHeaders)) }
    try {
        val request = requests.receive()
        assertEquals("/hold", request.path)
        assertSourceHttpHeaders(request.headers, sourceHttpHeaders)
        pending.cancelAndJoin()
        assertTrue(pending.isCancelled)
        assertTrue(requests.tryReceive().isFailure)
    } finally {
        pending.cancelAndJoin()
    }
}
