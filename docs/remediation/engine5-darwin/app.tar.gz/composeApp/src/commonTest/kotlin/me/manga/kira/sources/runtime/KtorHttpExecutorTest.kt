package me.manga.kira.sources.runtime

import io.ktor.client.engine.mock.respond
import io.ktor.client.plugins.HttpRedirect
import io.ktor.client.plugins.pluginOrNull
import io.ktor.client.request.get
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.Headers
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpMethod
import io.ktor.http.HttpStatusCode
import io.ktor.http.content.OutgoingContent
import io.ktor.http.headersOf
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.test.runTest
import me.manga.kira.sources.contracts.SourceHttpMethod
import me.manga.kira.sources.contracts.SourceRequest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertIs
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class KtorHttpExecutorTest {
    @Test
    fun child_returns_first_redirect_without_changing_parent_redirect_policy() = runTest {
        withSourceHttp({ request ->
            if (request.url.encodedPath == "/start") {
                respond("first hop", HttpStatusCode.Found, headersOf(HttpHeaders.Location, "/final"))
            } else {
                respond("final hop")
            }
        }) {
            assertNotNull(root.pluginOrNull(HttpRedirect))
            assertNull(child.pluginOrNull(HttpRedirect))
            val response = executor.execute(SourceRequest("$SOURCE_HTTP_ORIGIN/start", headers = sourceHttpHeaders))
            assertEquals(302, response.status)
            assertEquals("first hop", response.body)
            assertEquals("/final", response.headers[HttpHeaders.Location])
            assertEquals(listOf("/start"), engine.requestHistory.map { it.url.encodedPath })
            assertSourceHttpHeaders(engine.requestHistory.single().headers, sourceHttpHeaders)
            assertEquals("final hop", root.get("$SOURCE_HTTP_ORIGIN/start").bodyAsText())
            assertEquals(listOf("/start", "/start", "/final"), engine.requestHistory.map { it.url.encodedPath })
        }
    }

    @Test
    fun all_redirect_and_error_statuses_are_returned_instead_of_followed_or_thrown() = runTest {
        (sourceHttpRedirectStatuses + listOf(404, 503)).forEach { status ->
            withSourceHttp({
                respond("response", HttpStatusCode.fromValue(status), headersOf(HttpHeaders.Location, "/other"))
            }) {
                val response = executor.execute(SourceRequest("$SOURCE_HTTP_ORIGIN/start"))
                assertEquals(status, response.status)
                assertEquals("response", response.body)
                assertEquals(1, engine.requestHistory.size)
            }
        }
    }

    @Test
    fun single_location_preserves_commas_and_empty_reference_without_splitting() = runTest {
        listOf("/next,a?b=c,d", "").forEach { location ->
            withSourceHttp({
                respond("redirect", HttpStatusCode.Found, Headers.build {
                    append("lOcAtIoN", location)
                    append("X-Multi", "one")
                    append("X-Multi", "two")
                })
            }) {
                val response = executor.execute(SourceRequest("$SOURCE_HTTP_ORIGIN/start"))
                assertEquals(location, response.headers[HttpHeaders.Location])
                assertEquals("one, two", response.headers.entries.single { it.key.equals("X-Multi", true) }.value)
                assertEquals(1, engine.requestHistory.size)
            }
        }
    }

    @Test
    fun multiple_location_fields_are_omitted_even_if_identical_or_differently_cased() = runTest {
        listOf("/first", "/second").forEach { second ->
            withSourceHttp({
                respond("redirect", HttpStatusCode.Found, Headers.build {
                    append("Location", "/first")
                    append("location", second)
                })
            }) {
                val response = executor.execute(SourceRequest("$SOURCE_HTTP_ORIGIN/start"))
                assertTrue(response.headers.keys.none { it.equals(HttpHeaders.Location, true) })
                assertEquals(1, engine.requestHistory.size)
            }
        }
    }

    @Test
    fun form_keeps_static_then_repeated_filter_values_and_initial_headers() = runTest {
        withSourceHttp({ respond("ok") }) {
            executor.execute(
                SourceRequest(
                    url = "$SOURCE_HTTP_ORIGIN/form",
                    method = SourceHttpMethod.POST_FORM,
                    headers = sourceHttpHeaders,
                    formBody = listOf("static" to "first", "genre[]" to "action", "genre[]" to "sci fi"),
                ),
            )
            val sent = engine.requestHistory.single()
            assertEquals(HttpMethod.Post, sent.method)
            val body = assertIs<OutgoingContent.ByteArrayContent>(sent.body)
            assertTrue(body.contentType?.match(ContentType.Application.FormUrlEncoded) == true)
            assertEquals("static=first&genre%5B%5D=action&genre%5B%5D=sci+fi", body.bytes().decodeToString())
            assertSourceHttpHeaders(sent.headers, sourceHttpHeaders)
        }
    }

    @Test
    fun json_is_sent_verbatim_with_json_type_and_null_body_keeps_empty_object_default() = runTest {
        listOf("""{"ids":[2,1],"text":"synthetic"}""", null).forEach { json ->
            withSourceHttp({ respond("ok") }) {
                executor.execute(
                    SourceRequest(
                        url = "$SOURCE_HTTP_ORIGIN/json",
                        method = SourceHttpMethod.POST_JSON,
                        headers = sourceHttpHeaders,
                        jsonBody = json,
                    ),
                )
                val sent = engine.requestHistory.single()
                assertEquals(HttpMethod.Post, sent.method)
                val body = assertIs<OutgoingContent.ByteArrayContent>(sent.body)
                assertTrue(body.contentType?.match(ContentType.Application.Json) == true)
                assertEquals(json ?: "{}", body.bytes().decodeToString())
                assertSourceHttpHeaders(sent.headers, sourceHttpHeaders)
            }
        }
    }

    @Test
    fun cancelling_suspended_transport_cancels_the_call_without_another_send() = runTest {
        val entered = CompletableDeferred<Unit>()
        val stopped = CompletableDeferred<Unit>()
        var sends = 0
        withSourceHttp({
            sends++
            entered.complete(Unit)
            try {
                awaitCancellation()
            } finally {
                stopped.complete(Unit)
            }
        }) {
            val call = async { executor.execute(SourceRequest("$SOURCE_HTTP_ORIGIN/wait")) }
            entered.await()
            call.cancelAndJoin()
            stopped.await()
            assertTrue(call.isCancelled)
            assertEquals(1, sends)
        }
    }
}
